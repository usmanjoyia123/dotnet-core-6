﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter13
{
    public static class Extensions
    {
        public static bool IsGreaterThan(this int i, int value)
        {
            return (i > value);
        }
        public static bool IsGreaterThan(this int[] i, int value)
        {
            return (i.Length > value);
        }
        public static void DisplayType(this object obj)
        {
            Console.WriteLine("Type of object is => {0}", obj.GetType().Name);
        }
        public static void QueryOverStrings(this string[] s, string key)
        {
            IEnumerable<string> subset = s.Where(game =>
            game.Contains(key)).
            OrderBy(game => game).
            Select(game => game);
            foreach (string str in subset)
            {
                Console.WriteLine("Item: {0}", str);
            }
        }
        public static void GreaterThanTen(this int[] ints )
        {
            // .ToArray() or any other extension method will make it executed immediately
            // Immediate execution will not bring the updated/greatest results

            var subset = (from i in ints where i > 10 select i);//.ToArray();
            
            foreach (var v in subset.DefaultIfEmpty(-1))
                // SingleorDefault, FirstorDefault, LastorDefault
            {
                Console.WriteLine("{0} > 10", v);
            }
            Console.WriteLine();
            ints[1] = 15;
            subset = subset.ToArray();
            // Example of deferred Execution in Linq
            //Linq will bring the latest results
            foreach (var k in subset.DefaultIfEmpty(-1))
            {
                Console.WriteLine("{0} > 10", k);
            }
        }
    }
}
