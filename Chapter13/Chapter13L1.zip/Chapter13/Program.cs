﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Chapter13;
namespace Chapter13 { 
    class Program
    {
        private IEnumerable<string> redColor = GetStringSubset("Red");
        public static string [] GetStringSubset(string color)
        {
            string [] colors = { "Light Red", "Dark Red", "Red", "Black", "Dark Brown" };
            var subset = from g in colors where g.Contains (color) select g;
            return subset.ToArray();
        }
        public static void Main(string[] args)
        {
            string[] currentVideoGames = { "Morrowind", "Uncharted 2", "Fallout 3", "Daxter", "System Shock 2" };
            int[] nums = { 1, 3, 5 };
            Program p = new Program();
           // p.DisplayType();
            Console.WriteLine(nums.IsGreaterThan(5));
            Console.WriteLine(nums[0].IsGreaterThan(nums[1]));
            //currentVideoGames.QueryOverStrings(" ");


            // Assume we have an array of strings.

            currentVideoGames.QueryOverStrings(" ");
            nums.GreaterThanTen();

            Console.Clear();

            ArrayList list = new ArrayList()
            {
                new Car (){ PetName = "Civic", Color = "Black", Make= "Honda", Speed = 180},
                new Car ("Corolla", "Silver", "Toyota", 130),
                new Car ("Vitz", "Red", "Toyota", 100),
                new Car ("Swift", "White", "Suzuki", 110),
                new Car ("Grande", "Black", "Toyota", 180),
                new Car ("Prius", "Black", "Toyota", 160),
                new Car ("Sportage", "White", "KIA", 150)
            };
            

            Car c = new Car ("City", "White", "Honda", 120);
            Car c1 = new Car {
                PetName = "Yaris",
                Color = "Red",
                Make = "Toyota", 
                Speed = 120
            };
            Console.Clear();

            List < Car > Showroom = new List<Car>() {
                c, c1,
                new Car (){ PetName = "Civic", Color = "Black", Make= "Honda", Speed = 180},
                new Car ("Corolla", "Silver", "Toyota", 130),
                new Car ("Vitz", "Red", "Toyota", 100),
                new Car ("Swift", "White", "Suzuki", 110),
                new Car ("Grande", "Black", "Toyota", 180),
                new Car ("Prius", "Black", "Toyota", 160),
                new Car ("Sportage", "White", "KIA", 150)
            };

            Console.WriteLine("***Cars by Speed***\n");
            var cars_speed = Car.GetCarsBySpeed(Showroom, 110);
            Car.DisplaySubset(cars_speed);

            Console.WriteLine("***Cars by Make***\n");
            var cars_make = Car.GetCarsByMake(Showroom, "Honda");
            Car.DisplaySubset(cars_make);

            Console.WriteLine("***Cars by Name ***\n");
            var cars_name = Car.GetCarsByName(Showroom, "City");
            Car.DisplaySubset(cars_name);

            Console.WriteLine("***Cars by Color **\n");
            var cars_color = Car.GetCarsByColor(Showroom, "White");
            Car.DisplaySubset(cars_color);

            Console.WriteLine("*** Cars by Make and Color ***\n");
            var cars_MakeColor = Car.GetCarsByColorAndMake(Showroom, "Honda",  "White");
            Car.DisplaySubset(cars_MakeColor);

            
            Console.Clear();

            // To Implement IEnumerable Compatible Object Type in NonGeneric Collection

            var data = list.OfType<Car>();
            // try it with 'list'
            var tidyData = from g in data where g.PetName == " " orderby g select g;

            // .ofType<T>() can also help to filter the data of any T from non generic collection

            ArrayList arr_list = new ArrayList() {
                 5, 6, new Int32(), new Car (), "Usman", "Joyia"
            };


            
            Console.WriteLine();
            Console.ReadLine();
        }

    }
}